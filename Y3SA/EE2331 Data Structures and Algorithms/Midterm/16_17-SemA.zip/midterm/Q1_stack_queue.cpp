/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   stackAndQueue.cpp
 * Author: Van
 *
 * Created on 2016年10月29日 星期六, 下午7:18
 */

#include <cstdlib>
#include <iostream>
#include <stack>
#include <queue>

using namespace std;

class LIFO {
private:
    queue<int> q;
public:

    bool empty() {
        return q.empty();
    }

    int size() {
        return q.size();
    }
    void in(int x);
    int out();
};

void LIFO::in(int x) {
    q.push(x);
}

int LIFO::out() {
    int size = q.size();

    for (int i = 0; i < size - 1; i++) {
        q.push(q.front());
        q.pop();
    }

    // if the underlying queue is empty, exception will be thrown 
    int temp = q.front();
    q.pop();
    return temp;
}

//**************************************************************

class FIFO {
private:
    stack<int> s;
public:

    bool empty() {
        return s.empty();
    }

    int size() {
        return s.size();
    }

    void in(int x);
    int out();
};

void FIFO::in(int x) {
    s.push(x);
}

int FIFO::out() {

    // if the underlying stack is empty, exception will be thrown 
    int temp = s.top();
    s.pop();

    int result;
    if (s.size() > 0) {
        result = this->out();
        s.push(temp);
    } else
        return temp;

    return result;
}

/*
 * 
 */
int main(int argc, char** argv) {

    FIFO q;

    q.in(1);
    q.in(2);
    q.in(3);

    while (!q.empty())
        cout << q.out() << " ";

    cout << endl;

    LIFO s;
    s.in(1);
    s.in(2);
    s.in(3);

    while (!s.empty())
        cout << s.out() << " ";

    return 0;
}

