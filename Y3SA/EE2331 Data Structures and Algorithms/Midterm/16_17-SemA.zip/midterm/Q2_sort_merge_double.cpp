/* 
 * Student name:
 * Student ID  :
 *
 * 
 */

#include <cstdlib>
#include <cstdio>
#include <iostream>
#include <fstream>

using namespace std;

/* Linked list node */
struct node {
    int data;
    node* next;
    node* back;
};

//-------------------------- functions to be implemented by you

node* merge(node* list1, node* list2) {

    if (list1 == NULL || list2 == NULL)
        return list1 ? list1 : list2;

    node temp({0, NULL, NULL});
    node* dummy = &temp;
    node* tail = dummy;
    while (list1 != NULL && list2 != NULL) {
        if (list1->data < list2->data) {
            tail->next = list1;
            tail->next->back = tail;
            list1 = list1->next;
        } else {
            tail->next = list2;
            tail->next->back = tail;
            list2 = list2->next;
        }
        tail = tail->next;
    }

    if (list1 != NULL) {
        tail->next = list1;
        tail->next->back = tail;
    }
    if (list2 != NULL) {
        tail->next = list2;
        tail->next->back = tail;
    }

    if (dummy->next != NULL)
        dummy->next->back = NULL;
    return dummy->next;
}

node* rmerge(node* list1, node* list2) {

    if (list1 == NULL || list2 == NULL)
        return list1 ? list1 : list2;

    node* head;

    if (list1->data < list2->data) {
        head = list1;
        list1 = list1->next;
    } else {
        head = list2;
        list2 = list2->next;
    }

    head->next = rmerge(list1, list2);
    head->next->back = head;

    return head;
}

node* sort(node* list) {

    node temp({0, NULL, NULL});
    node* dummy = &temp;

    while (list != NULL) {

        // pick a node
        node* p = list;
        list = list->next;

        // ordered insert
        node* cur = dummy;
        while (cur->next != NULL && p->data > cur->next->data)
            cur = cur->next;

        // insert after cur
        p->next = cur->next; //(1)
        p->back = cur; //(2)
        if (cur->next != NULL) //current has a successor
            cur->next->back = p; //(3)
        cur->next = p; //(4)
    }

    if (dummy->next != NULL)
        dummy->next->back = NULL;
    return dummy->next;
}

// selection sort
node* rsort(node* list) {

    if (list == NULL)
        return NULL;

    // find min
    node* min = list;
    node* cur = list->next;
    while (cur != NULL) {
        if (cur->data < min->data)
            min = cur;
        cur = cur->next;
    }

    if (min->next != NULL)
        min->next->back = min->back; //(1)
    
    if (min->back != NULL)
        min->back->next = min->next; //(2)
    else
        list = min->next;   // min is the first node
        
    min->back = NULL;
    min->next = rsort(list);

    if(min->next != NULL)
        min->next->back = min;
    
    return min;
}

// insertion sort
node* rsort2(node* list) {

    if (list == NULL)
        return NULL;

    if (list->next == NULL) {
        list->back = NULL;
        return list;
    }

    node* p = list;
    list = list->next;

    node* sublist = rsort2(list);

    if (p->data < sublist->data) {
        p->next = sublist;
        p->back = NULL;
        sublist->back = p;
        return p;
    } else {
        node* cur = sublist;
        while (cur->next != NULL && p->data > cur->next->data)
            cur = cur->next;

        // insert after cur
        p->next = cur->next; //(1)
        p->back = cur; //(2)
        if (cur->next != NULL) //current has a successor
            cur->next->back = p; //(3)
        cur->next = p; //(4)

        return sublist;
    }
}

//-------------------------- functions prepared for you

/*
 * Helper class for creating/printing a doublely linked list from an array.
 */
class DListHelper {
public:
    // new a list based on array input

    static node* newList(int* arr, int n) {
        // static node freed automatically
        node temp({n, NULL, NULL});
        node* dummy = &temp;

        node* tail = dummy;
        for (int i = 0; i < n; i++) {
            tail->next = newNode(arr[i]);
            tail->next->back = tail;
            tail = tail->next;
        }

        if (dummy->next != NULL)
            dummy->next->back = NULL;

        return dummy->next; // without dummy header
    }

    // new one single node

    static node* newNode(int data) {
        return new node({data, NULL, NULL});
    }

    //print nodes in a given linked list

    static void printList(node *list) {
        
        if (list == NULL)
            return;
        else
            printf("%d ", list->data);

        while (list->next != NULL) {
            printf("%d ", list->next->data);
            list = list->next;
        }

        while (list->back != NULL) {
            printf("%d ", list->back->data);
            list = list->back;
        }
    }

    //print nodes in a given linked list

    static void deleteList(node *list) {
        node* temp;
        while (list != NULL) {
            temp = list;
            list = list->next;
            delete temp;
        }
    }
};

/*
 * Driver program to test above functions against default test cases.
 */

void testSort() {
    
    int arr1[] = {7, 1, 5, 3};
    node* list1 = DListHelper::newList(arr1, 4);
    cout << "list: ";
    DListHelper::printList(list1);
    cout << endl;

    cout << "sorted list: ";
    node* result = rsort(list1);
    DListHelper::printList(result);
    cout << endl;

    DListHelper::deleteList(result);
}

void testMerge() {
    
    int arr1[] = {1, 3};
    node* list1 = DListHelper::newList(arr1, 2);
    cout << "list 1: ";
    DListHelper::printList(list1);
    cout << endl;

    cout << "list 2: ";
    int arr2[] = {2, 4, 6};
    node* list2 = DListHelper::newList(arr2, 3);
    DListHelper::printList(list2);
    cout << endl;

    cout << "merged list: ";
    node* result = merge(list1, list2);
    DListHelper::printList(result);
    cout << endl << endl;

    DListHelper::deleteList(result);
}

int main(int argc, char** argv) {

    testMerge();
    testSort();

    return 0;
}

