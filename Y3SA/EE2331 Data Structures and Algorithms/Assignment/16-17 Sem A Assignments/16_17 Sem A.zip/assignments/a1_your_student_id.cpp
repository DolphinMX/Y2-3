/* 
 * Student name:
 * Student ID  :
 * 
 * EE2331 Data Structures and Alogorithms 2016/17 Sem A
 *
 * Assignment 1 - Maximum Sum Submatrix
 * Due  Date: 14 Oct 2016 (Friday)
 *
 * You are asked to implement a solution to find the maximum sum submatrix from 
 * a given square matrix. Your implementation cannot use any c++ built-in data 
 * structures or algorithms.
 * 
 * Some test cases are provided for you in a1_input.txt. But you are responsible 
 * to design additional test cases to verify if your algorithm fulfills the 
 * requirements. A different set of test cases will be used by grader.
 * 
 * Your program eventually will be ranked by the number of passed test cases and 
 * the execution time. Marks may be deducted if any problems were found 
 * e.g. wrong file name, wrong output format, late submission, etc.
 */

#include <cstdlib>
#include <iostream>
#include <fstream>
#include <iomanip> 
#include <ctime> 

#define SID 12345678        // Put Your SID here!

using namespace std;

/*
 * Define the members for the matrix structure. 
 * It is the only input argument to your algorithm, so you need to define 
 * sufficient data members to let you represent the input square matrix.
 */
struct matrix {
    
    
    
    
};

/*
 * Given a non-empty integer matrix M of size N*N, implement your algorithm to 
 * find the maximum sum submatrix S, which is represented by five numbers 
 * denoting its maximum sum (X), leftmost column (L), rightmost column (R), 
 * topmost row (T), and bottommost row (B).
 * 
 * The argument m is the sqaure matrix M. The function returns an array of the
 * the five numbers in this order: [X, L, R, T, B]
 * 
 * Note that if there are more than one submatrix with the greatest sum, then 
 * the one with larger size will be returned. For example,
 *
 *       4 -9 -9
 *  M = -9  1  1     where N = 3
 *      -9  1  1
 * 
 * The submatrix found is the four 1s located in lower right corner. 
 * So, the array to be returned is : [4 1 2 1 2]
 * 
 */
int* findSubmatrix(matrix& m) {

    
    

}

/*
 * Helper function. No modification is needed.
 * Run and measure the execution time of your algorithm. The output results are 
 * printed in a parsable format. 
 * 
 * No other function should attempt to output/print to screen!!!
 */
void runAndMeasure(int* (*algorithm)(matrix&), matrix& m) {
    clock_t start = clock();
    int* result = algorithm(m);
    clock_t end = clock();
    int time = (end - start) * 1000.0 / CLOCKS_PER_SEC;     // execution time in ms
    // SID, max sum, left, right, top, bottom, time
    printf("%d %d %d %d %d %d %d\n", SID, result[0], result[1], result[2], result[3], result[4], time);
    delete[] result;
}

/*
 * Driver program to test your algorithm against the test cases.
 */
int main(int argc, char** argv) {

    /*
     * The input file name is no longer hard-coded into program. You must obtain
     * it from the first command-line argument argv[1]. 
     * 
     * (1) Read the test cases from the input file according to its format specified.
     * (2) Run all test cases.
     * (3) For each test case, create the input matrix and call runAndMeasure()
     *     as follows:

            // create an empty matrix
            matrix m;   

            // Put your data into the matrix m
            // ...
            // ...
    
            runAndMeasure(findSubmatrix, m);
     */

    return 0;
}

