/* 
 * Student name:
 * Student ID  :
 * 
 * EE2331 Data Structures and Algorithms 2016/17 Sem A
 *
 * Assignment 2 - Pentomino Puzzle
 * Due  Date: 11 Nov 2016 (Friday)
 *
 * A pentomino is a plane geometric figure formed by joining five equal squares 
 * edge to edge. It is a polyomino with five cells. There are twelve pentominoes, 
 * not counting rotations and reflections as distinct. If reflections and rotations 
 * of a pentomino are considered distinct, there are 63 fixed pentominoes. A standard 
 * pentomino puzzle is to tile a rectangular box with the pentominoes, i.e. cover 
 * it without overlap and without gaps. Each of the 12 pentominoes has an area of 
 * 5 unit squares, so the box must have an area of 60 units. Possible sizes are 
 * 6x10, 5x12, 4x15 and 3x20. 

 * You are asked to write a program to find all solutions having the 12 pentominoes 
 * touching the edges of a rectangle box with specific size using backtracking. 
 *  
 * Some test cases are provided for you in a2_input.txt. But you are responsible 
 * to design additional test cases to verify if your algorithm fulfills the 
 * requirements. A different set of test cases will be used by grader.
 * 
 * Your program eventually will be ranked by the number of passed test cases and 
 * the execution time. Marks may be deducted if any problems were found 
 * e.g. wrong file name, wrong output format, late submission, etc.
 */

#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <iomanip> 
#include <ctime> 


#define SID 12345678        // Put Your SID here!

using namespace std;

/*
 * Define whatever members for the Box class as you need. 
 * It is the only input argument, except the counter, to your backtracking algorithm, 
 * so you need to define sufficient members to let you represent the puzzle.
 */
class Box {
public:
    
    Box(int r, int c) {
        
        // complete your constructor
        // . . .
        
    }

    /*
     * Print the result F (first solution), L (last solution) and N (number of solutions)
     * as required in the output format. If there is no solution, print 'nil' to replace
     * the solution string.
     * 
     * The function is called from main() when a puzzle is solved.
     * 
     */
    void output() const {
        // dummy output
        cout << "F " << "L " << "N";
    }
};

/*
 * Find all solutions having the 12 pentominoes touching the edges of the rectangle 
 * box using backtracking algorithm. The first argument 'count' is used to track the
 * progress of your backtracking algorithm. Its actual use depends on how you model
 * the problem.  
 */
void solve(int count, Box& box) {

    
    
    
}


/*
 * Driver program to test above functions against default test cases.
 * Input filename must be provided by command-line argument.
 * 
 * **** DON'T modify this main function. ****
 */
int main(int argc, char** argv) {

    ifstream fin(argv[1]);
    if (!fin) {
        cout << "Input file not found.";
        exit(1);
    }

    int testcase = 0;
    fin >> testcase;

    for (int t = 0; t < testcase; t++) {
        int row, col;
        fin >> row >> col;
        
        // run and measure
        clock_t start = clock();
        // create a box with specific dimension
        Box* box = new Box(row, col);
        solve(0, *box);
        // output result F, L and N
        box->output();
        clock_t end = clock();
        int time = (end - start) * 1000.0 / CLOCKS_PER_SEC;
        // output result T and S
        printf(" %d %d\n", time, SID);

        // clean memory for every test case
        delete box;
    }

    return 0;
}

